// Bump V on each deploy if you want to force-clear old caches.
const V="amaysst-v1",ASSETS=["./","./index.html","./offline.html","./manifest.webmanifest","./icons/icon-192.png","./icons/icon-512.png","./icons/maskable-512.png","./icons/apple-touch-icon.png"];
// Never cache anything that looks like login, tokens or API calls.
const SKIP=/\/(api|auth|login|signin|token|session|__)(\/|$)|firebase/i;
self.addEventListener("install",e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(ASSETS.map(u=>new Request(u,{cache:"reload"})))))});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x.startsWith("amaysst-")&&x!==V).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener("message",e=>{if(e.data==="SKIP_WAITING")self.skipWaiting()});
const ok=r=>r&&r.status===200&&r.type==="basic"&&!/no-store|private/i.test(r.headers.get("cache-control")||"");
const put=(q,r)=>{if(ok(r)){const c=r.clone();caches.open(V).then(x=>x.put(q,c))}return r};
self.addEventListener("fetch",e=>{const q=e.request,u=new URL(q.url);
if(q.method!=="GET"||u.origin!==location.origin||SKIP.test(u.pathname)||q.headers.has("Authorization"))return;
if(q.mode==="navigate"){// network first, then cached page, then offline page
e.respondWith(Promise.race([fetch(q),new Promise((_,j)=>setTimeout(j,4000))]).then(r=>put(q,r)).catch(()=>caches.match(q,{ignoreSearch:true}).then(r=>r||caches.match("./index.html")).then(r=>r||caches.match("./offline.html"))));return}
// static files: cached copy first, refreshed in the background
e.respondWith(caches.match(q).then(h=>{const n=fetch(q).then(r=>put(q,r));if(h){e.waitUntil(n.catch(()=>{}));return h}return n}))});
